#ifndef _XRT_VERSION_H_
#define _XRT_VERSION_H_

static const char xrt_build_version[] = "2.1.0";

static const char xrt_build_version_branch[] = "2018.3";

static const char xrt_build_version_hash[] = "e154bac9c685e8ae71b6068a4750c9ac3c05a932";

static const char xrt_build_version_hash_date[] = "Thu, 14 Nov 2019 13:05:44 -0800";

static const char xrt_build_version_date_rfc[] = "Tue, 10 Dec 2019 05:15:52 +0000";

static const char xrt_build_version_date[] = "2019-12-10 05:15:52";

static const char xrt_modified_files[] = "";

#define XRT_DRIVER_VERSION "2.1.0,e154bac9c685e8ae71b6068a4750c9ac3c05a932"

# ifdef __cplusplus
#include <iostream>
#include <string>

namespace xrt { 

class version {
 public:
  static void print(std::ostream & output)
  {
     output << "       XRT Build Version: " << xrt_build_version << std::endl;
     output << "    Build Version Branch: " << xrt_build_version_branch << std::endl;
     output << "      Build Version Hash: " << xrt_build_version_hash << std::endl;
     output << " Build Version Hash Date: " << xrt_build_version_hash_date << std::endl;
     output << "      Build Version Date: " << xrt_build_version_date_rfc << std::endl;
  
     std::string modifiedFiles(xrt_modified_files);
     if ( !modifiedFiles.empty() ) {
        const std::string& delimiters = ",";      // Our delimiter
        std::string::size_type lastPos = 0;
        int runningIndex = 1;
        while(lastPos < modifiedFiles.length() + 1) {
          if (runningIndex == 1) {
             output << "  Current Modified Files: ";
          } else {
             output << "                          ";
          }
          output << runningIndex++ << ") ";
  
          std::string::size_type pos = modifiedFiles.find_first_of(delimiters, lastPos);
  
          if (pos == std::string::npos) {
            pos = modifiedFiles.length();
          }
  
          output << modifiedFiles.substr(lastPos, pos-lastPos) << std::endl;
  
          lastPos = pos + 1;
        }
     }
  }
};
}
#endif

#endif 

